# Bank-Marketing
. Use machine learning techniques to predict the marketing campaign outcome and to find out factors, which affect the success of the campaign. 
